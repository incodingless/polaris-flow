# 来源与许可（provenance）

本文件记录本附带技能的来源，不参与模型上下文加载。

## 来源

| 项 | 值 |
|---|---|
| 技能名 | `diagram-design` |
| 仓库 | https://github.com/cathrynlavery/diagram-design |
| 上游版本 | `2.6`（`SKILL.md` frontmatter `metadata.version`） |
| 上游 commit | `7a12007b5a4246894f342a2e52e78facbc62eca3`（2026-10-21）。**这是钉版本的依据**：上游无 release tag，`BUNDLED_SKILL_SPECS` 用此 SHA，不跟随默认分支 |
| 许可 | MIT，Copyright (c) 2025 Cathryn Lavery |
| 拷入日期 | 2026-10-22 |
| 落盘位置 | `devops/vendor/bundled-skills/diagram-design/`（开发态后备副本，不入 git）→ 运行时由 `polaris init` 拉到 `~/.polaris/components/bundled-skills/diagram-design/` → 安装到用户项目 `<skills>/diagram-design/` |

## 选源说明

同名仓库有 5 个以上（`cathrynlavery` 上游、`SanHsien` 39 类维护 fork、`luffy666code` 40 类重绘版、
`ardith666` 镜像、`juanjolaz90` 西语版）。本项目取**上游**：其余都是派生，跟随派生的派生会让升级路径断裂。

代价是只有 13 类基础图，没有「把 `.drawio` / Mermaid / Excalidraw 重绘成 HTML」这一类能力。
若日后确需重绘能力，另起一项评估，不要直接换成 fork——会丢掉与上游的对齐关系。

## 与原技能的差异

**无内容改动。** `SKILL.md`、`references/`、`assets/`、`scripts/` 与上游 `skills/diagram-design/` 逐字节相同。
`assets/example-*.html`（约 4.3MB）**有意保留**：`SKILL.md` 把它们作为三种视觉变体
（minimal light / minimal dark / full editorial）的对照示例，删掉会失去质量锚点。

**只拷了技能目录，未拷仓库其余部分。** 上游仓库根部的 `commands/`、`docs/`、`prompts/`、`scripts/`
没有拷入。副作用：`SKILL.md` 有一处提到「在仓库 checkout 里可跑 `<repo-root>/scripts/verify-motion.py`」——
安装后的形态跑不了，`SKILL.md` 原文已给出替代做法（手工检查静态帧与 reduced-motion 状态），故不阻断。

## 运行依赖

- 生成阶段无外部依赖（产出单文件 HTML + 内联 SVG）。
- `scripts/*.py`（`drawio_extract.py` / `mermaid_extract.py` / `excalidraw_extract.py` / `export_png.py` /
  `export_svg.py` / `self_check.py`）需要 **Python 3**；仅在使用导入、导出、自检这些能力时才需要，
  纯生成不依赖。缺 Python 时应降级为不跑脚本，不得伪造「已校验」。

## 升级方式

手动，同 `archify`：拉上游 → 用新的 `skills/diagram-design/` 覆盖 → 更新本文件的版本 / commit / 日期 →
跑一遍生成实测。不做自动同步。

## 已知不足

- 上游质量评价体系（editorial design system）偏英文排版场景，中文长文本的换行与字重未经验证，
  落到中文设计文档时需实测。
