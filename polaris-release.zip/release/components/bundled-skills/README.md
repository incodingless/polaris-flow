# 附带技能（bundled skills）

随 polaris 分发的**第三方图表技能**：`archify` 与 `diagram-design`。

## 为什么放在 `devops/vendor/`

外部引入的框架与技能统一收在 `devops/vendor/`，便于清点与升级。本目录与 `superpowers/`、
`tgz/` 同性质：

| | `devops/vendor/` | `assets/` |
|---|---|---|
| 进 git | ❌（`.gitignore: devops/vendor/*`） | ✅ |
| 进 npm 包 | ❌（`package.json` files 不含 devops） | ✅ |
| 谁用 | 维护者；`package.sh` 打进 `release/components/` | 运行时 `readAssets()` |
| 性质 | **后备副本**（优先从 GitHub 下载） | 包内分发资产 |
| 丢了会怎样 | 下次 init / 打包重新拉 | 产品缺件 |

**不提交 git 是有意的**：这些副本只为「网络慢、下载超时」时保住一次安装成功率，
上游始终是 GitHub。本机没有副本时，`polaris init` 会现拉一份。

## 安装通道

```
polaris init
  └─ ensureBundledSkillsSource()          ① GitHub 浅克隆 → ~/.polaris/components/bundled-skills/
       ├─ 已有本地副本 → 跳过第①步
       └─ 拉取失败/超时 → 记 missing，不阻断 init
  └─ copyBundledSkillsToPlatform()        ② 本地副本 → <skills 根>/<name>/
```

- 离线安装包：`package.sh` 把本目录打进 `release/components/bundled-skills/`，
  `install.sh` 的 preseed 再落到 `~/.polaris/components/bundled-skills/` —— 走的是同一条本地通道。
- 指定本地源：`POLARIS_BUNDLED_SKILLS_SOURCE=<目录>`（显式指定后**不联网**）。

## 与 Polaris 技能族的三点差别

| 维度 | `assets/<lang>/skills/` | 本目录 |
|---|---|---|
| 身份 | Polaris 工作流技能（族 / 叶） | **外部工具**，不是流程里的一环 |
| 落盘 | `<skills>/polaris/<族>/<技能>` 或 `<skills>/polaris-<族>-<技能>` | `<skills>/<技能名>/`（原样） |
| 名称改写 | 替换 `{{SKN_SPR}}` | 不改写 |
| policies 注入 | 注入每个叶技能 | 不注入 |
| 资产校验 | 受「无跨技能 `../` 引用、无幽灵占位符」约束 | 不受 |

判据：**它是不是 Polaris 工作流的一个阶段？** 是 → `assets/<lang>/skills/`；只是被顺手调用的工具 → 这里。

## 当前内容

| 目录 | 上游 | 版本 | 许可 | 用途 |
|------|------|------|------|------|
| `archify/` | [tt-a1i/archify](https://github.com/tt-a1i/archify) | v3.2.0 | MIT | 结构化图：架构 / 时序 / 数据流 / ERD / 类图等 10 类，JSON IR + schema 校验，可做架构 delta 对比 |
| `diagram-design/` | [cathrynlavery/diagram-design](https://github.com/cathrynlavery/diagram-design) | v2.6 | MIT | 编辑级视觉图：13 类，三种视觉变体，能吃 Mermaid / drawio / Excalidraw 源码 |

两者都只服务**交付图**（给人看、能贴出去）。设计文档正文的图仍是 Mermaid，见
`assets/zh/skills/coding/design/templates/detail-design-template.md` 的「图表要求」。

## 裁剪

`archify/examples/*.html`（15 个，12MB，渲染成品）不进本地副本；`examples/*.json`（33 个，360KB）
保留 —— SKILL.md 按名引用它们作 schema 示例。裁剪规则写在代码里
（`src/core/integrations/bundled-skills.ts` 的 `BUNDLED_SKILL_SPECS[].exclude`），
手工 clone 补齐时也要照着删，否则本地副本与自动拉取的形态不一致。

`diagram-design/assets/example-*.html` **保留**：SKILL.md 把它们作为三种视觉变体的对照示例。

## 升级

**一条命令，别手工改三处。**

```bash
node devops/sync-bundled-skills.mjs            # 只检查：本地钉值 vs 上游最新（不改任何文件）
node devops/sync-bundled-skills.mjs --update   # 升级：改钉值 + 重拉 vendor + 更新 PROVENANCE
```

`--update` 做三件事，缺一不可：改写 `src/core/integrations/bundled-skills.ts` 里的钉值、
整目录替换 `devops/vendor/bundled-skills/<name>/`（按规则裁剪）、更新 `PROVENANCE.md` 的 commit 与日期。
拉取失败不留半成品（先拉到临时目录，成功才替换）。

升级后 `~/.polaris/components/bundled-skills/` 里还是旧的，但不用管：副本带
`.polaris-bundled-ref` 版本标记，下次 `polaris init` 发现标记与钉值不一致会自动重拉。

**为什么没有定时自动升级**：技能一升级就可能改变行为，且没有测试覆盖。定期追新的收益
低于风险，所以只提供「检查 + 手动升级」，由你在发版前决定。
