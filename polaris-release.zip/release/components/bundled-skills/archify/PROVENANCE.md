# 来源与许可（provenance）

本文件记录本附带技能的来源，不参与模型上下文加载。

## 来源

| 项 | 值 |
|---|---|
| 技能名 | `archify` |
| 仓库 | https://github.com/tt-a1i/archify |
| 上游版本 | `3.2.0`（`skill-release.json`） |
| 上游 commit | `25cf370`（2026-10-19，浅克隆取 HEAD） |
| 许可 | MIT，Copyright (c) 2026 tt-a1i (Archify) |
| 拷入日期 | 2026-10-22 |
| 落盘位置 | `devops/vendor/bundled-skills/archify/`（开发态后备副本，不入 git）→ 运行时由 `polaris init` 拉到 `~/.polaris/components/bundled-skills/archify/` → 安装到用户项目 `<skills>/archify/` |

## 与原技能的差异

**裁剪（唯一改动）**

- 删除 `examples/*.html`（15 个文件，约 12MB）：这些是渲染后的成品演示，纯展示用。
- 保留 `examples/*.json`（33 个文件，约 360KB）：`SKILL.md` 按文件名引用它们作为各图类型的 schema 示例
  （如 `examples/web-app.architecture.json`），属于技能运行时要读的内容。

**未改动**

- `SKILL.md` 与全部 `references/`、`schemas/`、`bin/`、`renderers/`、`recipes/`、`explainer/`、`locales/`、
  `assets/`、`scripts/` 均与上游逐字节相同。
- 未做 polaris 命名改写（不加 `{{SKN_SPR}}`、不改 frontmatter `name`）：本技能不是 Polaris 工作流技能，
  按原样安装到 `<skills>/archify/`，不进 `polaris/` 命名空间。见同目录上级 `README.md` 的判据。

## 运行依赖

- Node.js ≥ 18（`bin/archify.mjs` 自称零依赖 CLI）。
- 生成阶段不需要浏览器、不需要 Graphviz / Python。
- 唯一可选联网行为：启动时向固定清单发一次更新检查（`ARCHIFY_UPDATE_CHECK_DISABLED=1` 可关闭）。

## 升级方式

手动。流程：拉取上游 → 用上游 `archify/` 覆盖本目录 → 重新删 `examples/*.html` → 更新本文件的上游版本、
commit 与日期。不要把本目录纳入任何自动同步脚本：上游结构变化会静默改变技能行为，需要人工过一遍。

## 已知不足

- `examples/` 缺了 HTML 成品，若模型想"照着成品的样子画"只能读 JSON IR 与 `references/` 里的规格说明。
- 上游没有为「被裁剪后是否仍能工作」提供任何保证，需在升级时实测一次 `doctor` 与一次 `deliver`。
